// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init()
const db = cloud.database();
const got = require("got");
const request = require("request-promise");

const APPID = "wx6fefbf5034d7d192";
const APPSECRET = "188cb0d11aa9e2bf31a1143b7791976f";
const tokenurl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + APPID + "&secret=" + APPSECRET;
let checkurl = "https://api.weixin.qq.com/wxa/msg_sec_check?access_token=";

// 云函数入口函数
exports.main = async (event, context) => {
  const content = event.content;
  const author = event.author;
  const location = event.location;
  const fileList = event.fileList;
  const type = event.type;
  let video = event.video;
  const device = event.device;
  if (fileList) {
    for (var i = 0; i < fileList.length; i++) {
      fileList[i] = getImageUrl(fileList[i]);
    }
  }
  if (video) {
    video = getImageUrl(video);
  }  
  const tokenResponse = await got(tokenurl);
  const token = JSON.parse(tokenResponse.body).access_token;
  const checkResp = await request.post({
    uri: checkurl+token,
    method: "POST",
    body: {
      content: content
    },
    json: true
  });
  console.log("=============" + checkResp);
  const errcode = checkResp.errcode;
  if (errcode == 0) {
    return await db.collection("weibo").add({
      data: {
        content: content,
        location: location,
        author: author,
        fileList: fileList,
        video: video,
        create_time: db.serverDate(),
        device: device,
        type: type
      }
    })
  } else {
    return {
      errcode:1,
      errmsg:"您的内容有风险，请修改后发布！"
    }
  }
  //return checkResp;
}

function getImageUrl(fileId) {
  const baseUrl = "https://736a-sjx-a1nxp-1300186140.tcb.qcloud.la";
  const baseFileId = "cloud://sjx-a1nxp.736a-sjx-a1nxp-1300186140";
  const path = fileId.replace(baseFileId,"");
  const imageUrl = baseUrl + path;
  return imageUrl;
}
