// weibo/pages/index/index.js
const app = getApp();
const db = wx.cloud.database();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    hasmore: true,
    weibos:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initImageSize();
    this.loadWeibos();
  },

  onPullDownRefresh: function() {
    this.loadWeibos(0);
  },
  // 页面滚动到最底部
  onReachBottom: function() {
    this.loadWeibos(this.data.weibos.length,1);
  },

  loadWeibos: function(start = 0,type = 0) {
    const that = this;
    wx.cloud.callFunction({
      name:"getWeibos",
      data: {
        start: start
      }
    }).then(res => {
      //console.log(res);
      const weibos = res.result;
      let hasmore = true;
      if (!weibos || weibos.length < 5) {
        hasmore = false;
        if (!weibos) {
          return;
        }
      }
      // weibos.forEach((value, index) => {
      //   value.create_time = value.create_time.getTime();
      // });
      let newData = [];
      if (type == 1) {
        newData = that.data.weibos.concat(weibos);
      } else {
        newData = weibos;
      };      
      that.setData({
        weibos: newData,
        hasmore: hasmore
      })
    })
  },

  onShow: function() {
    this.loadWeibos();
    wx.pageScrollTo(0);
  },

  initImageSize: function () {
    const windowWidth = wx.getSystemInfoSync().windowWidth;
    const weiboWidth = windowWidth - 30;
    const twoImageSize = (weiboWidth - 2.5)/2;
    const threeImageSize = (weiboWidth - 2.5*2)/3;
    this.setData({
      twoImageSize:twoImageSize,
      threeImageSize:threeImageSize
    })    
  },

  onWriteWeiboTap: function (event) {
    const that = this;
    if (app.isLogin()) {
      wx.showActionSheet({
        itemList: ["文字","照片","视频"],
        success: res => {
          const tapIndex = res.tapIndex;
          if (tapIndex == 0) {
            wx.navigateTo({
              url: '../writeweibo/writeweibo?type=' + tapIndex,
            })  
          } else if (tapIndex == 1) {
            wx.chooseImage({
              success: function(res) {
                const tempImages = res.tempFilePaths;
                that.setData({
                  tempImages: tempImages
                })   
                wx.navigateTo({
                  url: '../writeweibo/writeweibo?type=' + tapIndex,
                })               
              },
            })
          } else if (tapIndex == 2) {
            wx.chooseVideo({
              success: res => {
                const tempVideo = res.tempFilePath;
                that.setData({
                  tempVideo: tempVideo
                })
                wx.navigateTo({
                  url: '../writeweibo/writeweibo?type=' + tapIndex,
                })  
              }
            })
          }
                  
        }
      })
    } else {
      wx.navigateTo({
        url:"../login/login"
      })
    }
  },

  onImageTap: function(event) {
    const imageIndex = event.target.dataset.imageindex;
    const weiboIndex = event.target.dataset.weiboindex;
    const curImageList = this.data.weibos[weiboIndex].fileList;
    const curImage = curImageList[imageIndex];
    wx.previewImage({
      urls:curImageList,
      current:curImage
    })
  },

  onPraiseTap: function(event) {
    const that = this;
    const weiboIndex = event.currentTarget.dataset.weiboindex;
    const weibos = that.data.weibos;
    const weibo = weibos[weiboIndex];
    const openId = app.globalData.userInfo.openId;
    if (!weibo.isPraised) {
      wx.cloud.callFunction({
        name: "praise",
        data: {
          weiboId: weibo._id,
          praise: true
        },
        success: res => {
          if (!weibo.praises) {
            weibo.praiseList = [openId];
          } else {
            weibo.praiseList.push(openId);
          }
          weibo.isPraised = true;
          weibos[weiboIndex] = weibo;
          that.setData({
            weibos: weibos
          })
        }
      })
    } else {
      wx.cloud.callFunction({
        name: "praise",
        data: {
          weiboId: weibo._id,
          praise: false
        }
      }).then(res => {
        const newPraiseList = [];
        const praiseList = weibo.praiseList;
        praiseList.forEach((value, index) => {
          if (value != openId) {
            newPraiseList.push(value);
          }
        });
        weibo.praiseList = newPraiseList;
        weibo.isPraised = false;
        weibos[weiboIndex] = weibo;
        that.setData({
          weibos: weibos
        })
      })
    }
    
  }
})